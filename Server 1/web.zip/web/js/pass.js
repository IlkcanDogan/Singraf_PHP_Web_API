var Sifre1 = getElementById('Sifre1');
var Sifre2 = getElementById('Sifre2');

if(Sifre1 == Sifre2){
	alert('a');
}